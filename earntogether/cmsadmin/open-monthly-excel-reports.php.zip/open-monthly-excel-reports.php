<?php 
ob_start();
include("../lib/config.php");
/*   CSV Export*/
			  function escape_csv_value($value) {
    $value = str_replace('"', '""', $value); // First off escape all " and make them ""
    if(preg_match('/,/', $value) or preg_match("/\n/", $value) or preg_match('/"/', $value)) { // Check if I have any commas or new lines
        return '"'.$value.'"'; // If I have new lines or commas escape them
    } else {
        return $value; // If no new lines or commas just return the value
    }
}

function redirectURL($url) {
	    echo '<script> window.location.href="'.$url.'"
		</script>"';

}

        /*header("Content-type: text/csv");
        header("Content-Disposition: attachment; filename=open-monthly-excel-reports.csv");
        header("Pragma: no-cache");
        header("Expires: 0");*/
		if(isset($_POST['Show'])){
			$from=$_POST['from'];
            $end_date=$_POST['end_date'];
			$id=$_POST['list'];
			$query123=$_POST['qry'];
			$date=date('Y-m-d');
			$description=$_POST['description'];
			//$title = '';
            //$title .= "Userid,Level Income,Total,Beneficiary Name ,Beneficiary Ac No,Bank Name,Branch Name,IFSC,Start Date,End Date"."\n";
            //echo $title;
            if(!empty($id)){
                foreach($id as $check) 
                {
			  
          			$selectuser_id=$check;
          			$request_amount=$amount['amt'];
                    $request_amount=$request_amount;
                    $sql = "select * from user_registration where user_id='$check'";
                    $res = mysqli_query($GLOBALS["___mysqli_ston"], $sql);
                    $dbts = mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], $sql));
                    $current_sub=mysqli_fetch_assoc(mysqli_query($GLOBALS["___mysqli_ston"], "select * from status_maintenance where id='".$dbts['user_plan']."'"));
					$target = $current_sub['amount'];	
					$totc_unpaid = 0;
					$total = 0;
					$content = '';

					while($data1=mysqli_fetch_assoc($res)){
                                        
                        $purchasetotal=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select sum(total_invoice_cv) as totalpurchase from amount_detail where purchase_date between '".date('Y-m-d')."' and '".date('Y-m-t')."' and user_id='".$data1['user_id']."'")); 
                        $totalpurchase = $purchasetotal['totalpurchase'];
                    
                    
                        $data11=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select sum(credit_amt) as leadtot1 from credit_debit where user_id='".$data1['user_id']."' and ttype='Level Income' and status=0 $query123")); 
                        if($data11['leadtot1']!=''){
                            $tot1 = $data11['leadtot1'];
                        }
                        else{
                            $tot1 = 0;
                        }
                        $strt = date('Y-m-d');
                        $end = date('Y-m-t');
                    
                        $data13=mysqli_fetch_array(mysqli_query($GLOBALS["___mysqli_ston"], "select sum(credit_amt) as leadtot3 from credit_debit where user_id='".$data1['user_id']."' and ttype='Co-founder Income' and status=0 $query123")); 
                        if($data13['leadtot3']!='')
                        {
                            $tot3 = $data13['leadtot3'];
                        }
                        else{
                            $tot3 = 0;
                        }
                    
                        if($tot1>0 || $tot3>0){
                             $total=$tot1+$tot3;
                        	$total1=$tot1+$tot3;
                        } 
                    }

                    $invoice_no=rand(100000,999999);
                	if($target<=$totalpurchase){
                        	$urls="http://".$_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
                            $date = date('Y-m-d');
                            mysqli_query($GLOBALS["___mysqli_ston"], "update final_e_wallet set amount=(amount+$total) where user_id='$check'");
                            //mysqli_query($GLOBALS["___mysqli_ston"], "insert into closing_credit_debit values(NULL,'$invoice_no','$check','$total','$tot1','$date','NA','NA','$tot2')");	  
                            mysqli_query($GLOBALS["___mysqli_ston"], "update credit_debit set status=1 where user_id='$check' and status=0 and ttype=('Level Income' || 'Co-founder Income')");
                          	
                    	}
                }	
            }	    
	    }   
		 
			
			
			
		header("location:monthly-business-report.php");
		
		   
		   
		   ?>
		   